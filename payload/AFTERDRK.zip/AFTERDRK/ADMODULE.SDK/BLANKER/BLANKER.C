/*
		AD GRAPHICS MODULE
		BLANKER - JUST BLANKS THE SCREEN (NO MORE, NO LESS)

		BY (INSERT NAME HERE)

		SAMPLE SOURCE CODE OF AFTER DARK WINDOWS MODULE
		DEMONSTRATES
			- MINIMUM STANDARD MODULE STRUCTURE
			- SIMPLE GDI GRAPHICS
*/

#include "module.h"
#include "blanker.h"

/*
*   SYSTEM GLOBALS
*/

extern  HANDLE  hLibInst;   //  HANDLE TO THIS MODULE (DLL)
extern  HDC  hDC;           //  MODULE DISPLAY CONTEXT
extern  LPSYSTEM lpSystem;  //  POINTER TO AD SYSTEM PARAM BLOCK
extern  LPMODULE lpModule;  //  POINTER TO MODULE'S PARAMETERS

/*
*   BLANKER GLOBALS
*/

//  PUT GLOBALS HERE


/*
		 USER-DEFINED ROUTINES
		 - DoPreInitialize
		 - DoInitialize
		 - DoBlank
		 - DoDrawFrame
		 - DoClose
		 - DoControl
		 - DoSelected
		 - DoAbout
		 - DoButtonMessage
*/

/*
*      MODULE ABOUT TO GO TO SLEEP (PULL DOWN DLOGS, ETC.)
*/
int DoPreInitialize ()
{

}

/*
*      MODULE INITIALIZATION ROUTINE
*/
int DoInitialize ()
{

  return NOERROR;
}


/*    
*   MODULE SCREEN BLANKING ROUTINE
*/
int DoBlank ()
{ 
	static  RECT  rBlank;

	SetRect (&rBlank, 0, 0, lpModule->ptRgnSize.x, lpModule->ptRgnSize.y);
	FillRect (hDC, &rBlank, GetStockObject (BLACK_BRUSH));

	return NOERROR;
}


/*
*   MODULE GRAPHICS ROUTINE
*/
int DoDrawFrame ()
{

  return NOERROR;
}

/*    
*   CLOSE MODULE, FREE USED MEMORY, ETC..
*/
int DoClose ()
{
  return NOERROR;   
}

/*
*   MODULE IS SELECTED
*/
int  DoSelected ()
{

	return NOERROR;
}

/*
*   MODULE'S ABOUT INFO SELECTED
*/
int  DoAbout ()
{

	return NOERROR;
}

/*
*   BUTTON CLICKED ON A MODULE CONTROL
*/
int  DoButtonMessage (iControl)
int iControl;
{
	switch (iControl)
	{
		case 0:
			break;

		case 1:
			break;

		case 2:
			break;

		case 3:
			break;
	}
	return NOERROR;
}



